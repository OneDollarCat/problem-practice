# Problem 1: Reverse the Numbers

## 📜 Problem statement

You are given a number `n`, followed by `n` integers.  
Your task is to print the numbers in **reverse order**, separated by a space.

----------

## 📟 Input Format

-   The first line contains an integer `n` – the number of integers to read.
-   The second line contains `n` integers separated by spaces.

----------

## 🖨 Output Format

-   Print the `n` integers in reverse order, space-separated, all in one line.

----------

## 🧪 Example

### Input

```
5  
10 20 30 40 50  

```

### Output

```
50 40 30 20 10  

```

----------

## ✋ Constraints

-   `1 <= n <= 10^5`
-   `-10^9 <= element <= 10^9

----------

## 🧠 How I will solve this
Since the constraints of each element are from -10<sup>9</sup> to 10<sup>9</sup>, I will store them in a **C++** `vector` of `int` data type.
And since `n` is from 1 to 10<sup>5</sup>, I will declare `n` as a **variable** of `int` data type.
I will then use a `foor` loop to read the inputs and output the inputs in **reverse-order**.

